var ContactUs = function () {

    return {
        //main function to initiate the module
        init: function () {
			var map;
			$(document).ready(function(){
			  map = new GMaps({
				div: '#map',
				lat: 10.011083,
				lng: 76.314901,
				zoom: 15,
			  });
			   var marker = map.addMarker({
			        lat: 10.010483,
			        lng: 76.314901,
			        title: 'Loop, Inc.',
		            infoWindow: {
		                content: "<div style='height: 135px; width: 250px;'><b>Markuplab Technologies (P) Ltd.</b><br />34/347/E, Sangamam, <br />Sangamam Lane, Padivattom, <br />Cochin-24, Kerala.<br /><abbr title='Phone'>P:</abbr> (+91) 484-2806790, (+91) 999 5785 136 <br />Email: <a href='mailto:info@markuplab.com'>info@markuplab.com</a></div>"
		            }
			   });


			   marker.infoWindow.open(map, marker);
			});
        }
    };

}();